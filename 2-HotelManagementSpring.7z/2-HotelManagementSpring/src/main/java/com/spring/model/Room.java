package com.spring.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
 
@Entity
@Table(name = "rooms")
public class Room{
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int roomID;
	private String type;
	 private int price;
	 private int roomNumber;
	 private boolean isAvailable;
 
	

		public int getRoomID() {
		return roomID;
	}

	public void setRoomID(int roomID) {
		this.roomID = roomID;
	}

		public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(int roomNumber) {
		this.roomNumber = roomNumber;
	}

	public boolean isAvailable() {
		return isAvailable;
	}

	public void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}



	@OneToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;
 
	public Customer getCustomer() {
		return customer;
	}
 
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	
 
	public Room(int roomID, String type, int price, int roomNumber, boolean isAvailable, Customer customer) {
		super();
		this.roomID = roomID;
		this.type = type;
		this.price = price;
		this.roomNumber = roomNumber;
		this.isAvailable = isAvailable;
		this.customer = customer;
	}

	public Room() {
		super();
	}

	@Override
	public String toString() {
		return "Room [roomID=" + roomID + ", type=" + type + ", price=" + price + ", roomNumber=" + roomNumber
				+ ", isAvailable=" + isAvailable + ", customer=" + customer + "]";
	}
	
	
 
	
		
}