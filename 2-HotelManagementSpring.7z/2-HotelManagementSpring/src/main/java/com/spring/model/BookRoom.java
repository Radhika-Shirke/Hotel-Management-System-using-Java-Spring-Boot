package com.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "bookRoom")
public class BookRoom {
	
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "roomID")
	private int roomID;
	
	@Column(name = "custId")
	private int custId;
	
	@Column(name = "roomNumber")
	private int roomNumber;

	public int getRoomID() {
		return roomID;
	}

	public void setRoomID(int roomID) {
		this.roomID = roomID;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public int getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(int roomNumber) {
		this.roomNumber = roomNumber;
	}

	public BookRoom(int roomID, int custId, int roomNumber) {
		super();
		this.roomID = roomID;
		this.custId = custId;
		this.roomNumber = roomNumber;
	}

	public BookRoom() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "BookRoom [roomID=" + roomID + ", custId=" + custId + ", roomNumber=" + roomNumber + "]";
	}
	
	

}
