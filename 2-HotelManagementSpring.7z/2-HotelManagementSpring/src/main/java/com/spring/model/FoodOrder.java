package com.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "FoodOrder")
public class FoodOrder {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "foodID")
	private int foodID;
	
	@Column(name = "custId")
	private int custId;
	
	@Column(name = "foodPrice")
	private int foodPrice;

	@Column(name = "fooItemName")
	private String fooItemName;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getFoodID() {
		return foodID;
	}

	public void setFoodID(int foodID) {
		this.foodID = foodID;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public int getFoodPrice() {
		return foodPrice;
	}

	public void setFoodPrice(int foodPrice) {
		this.foodPrice = foodPrice;
	}

	
	public String getFooItemName() {
		return fooItemName;
	}

	public void setFooItemName(String fooItemName) {
		this.fooItemName = fooItemName;
	}

	

	public FoodOrder(int id, int foodID, int custId, int foodPrice, String fooItemName) {
		super();
		this.id = id;
		this.foodID = foodID;
		this.custId = custId;
		this.foodPrice = foodPrice;
		this.fooItemName = fooItemName;
	}

	public FoodOrder() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "FoodOrder [id=" + id + ", foodID=" + foodID + ", custId=" + custId + ", foodPrice=" + foodPrice
				+ ", fooItemName=" + fooItemName + "]";
	}


}
