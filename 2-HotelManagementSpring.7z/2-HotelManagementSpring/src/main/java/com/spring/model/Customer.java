package com.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Customer_Details")
public class Customer {
 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CustomerID")
	private int custId;
 
	@Column(name = "CustomerName")
	private String name;
 
	@Column(name = "AadharNo")
	private String aadharNo;
 
	@Column(name = "Address")
	private String address;
 
	@Column(name = "PhoneNo")
	private String phoneNo;
 
	//one customer will access only one room
	@OneToOne(mappedBy = "customer")
	@JoinColumn(name = "roomID")
	private Room room;
 
	public Customer() {
 
	}
 
	public Customer(int custId, String name, String aadharNo, String address, String phoneNo, Room room) {
		super();
		this.custId = custId;
		this.name = name;
		this.aadharNo = aadharNo;
		this.address = address;
		this.phoneNo = phoneNo;
		this.room = room;
	}
 
	public int getCustId() {
		return custId;
	}
 
	public void setCustId(int custId) {
		this.custId = custId;
	}
 
	public String getName() {
		return name;
	}
 
	public void setName(String name) {
		this.name = name;
	}
 
	public String getAadharNo() {
		return aadharNo;
	}
 
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
 
	public String getAddress() {
		return address;
	}
 
	public void setAddress(String address) {
		this.address = address;
	}
 
	public String getPhoneNo() {
		return phoneNo;
	}
 
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
 
	public Room getRoom() {
		return room;
	}
 
	public void setRoom(Room room) {
		this.room = room;
	}
 
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", name=" + name + ", aadharNo=" + aadharNo + ", address=" + address
				+ ", phoneNo=" + phoneNo + ", room=" + room + "]";
	}
 
}