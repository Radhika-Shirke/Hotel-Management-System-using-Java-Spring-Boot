package com.spring.DAO;

import java.util.List;

import javax.persistence.criteria.CriteriaQuery;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.model.BookRoom;
import com.spring.model.Customer;

@Repository
public class BookRoomDAOImpl implements BookRoomDAO {
	
	@Autowired
	private SessionFactory sessionFactory;

	protected Session getSession() {
		return sessionFactory.getCurrentSession();
	}

	@Override
	@Transactional
	public void save(BookRoom bookRoom) {
		getSession().save(bookRoom);
		
	}

	@Override
	@Transactional
	public List<BookRoom> fetchAllBookedRoom() {
		CriteriaQuery<BookRoom> criteria=getSession().getCriteriaBuilder().createQuery(BookRoom.class);
		criteria.select(criteria.from(BookRoom.class));
		
		return getSession().createQuery(criteria).getResultList();
	}

}
