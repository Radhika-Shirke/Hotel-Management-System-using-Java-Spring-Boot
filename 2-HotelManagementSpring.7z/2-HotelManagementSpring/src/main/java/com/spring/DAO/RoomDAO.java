package com.spring.DAO;

import java.util.List;

import com.spring.model.Room;

public interface RoomDAO {
	public void save(Room room);
	public List<Room> fetchAllRoom();
	public Room fetchRoomById(int roomID);
	//public void update(Room room);
}
