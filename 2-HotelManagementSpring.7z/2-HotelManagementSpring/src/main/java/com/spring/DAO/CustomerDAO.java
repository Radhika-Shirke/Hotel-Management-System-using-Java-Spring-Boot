package com.spring.DAO;

import java.util.List;

import com.spring.model.Customer;
import com.spring.model.Room;

public interface CustomerDAO {
	public void save(Customer customer);
	public List<Customer> fetchAllCustomer();
}
