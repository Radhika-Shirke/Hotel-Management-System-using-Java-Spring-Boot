package com.spring.DAO;

import java.util.List;

import javax.persistence.criteria.CriteriaQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.NativeQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.model.Room;

@Repository
public class RoomDAOImpl  implements RoomDAO {

	@Autowired
	private SessionFactory sessionFactory;

	protected Session getSession() {
		return sessionFactory.getCurrentSession();
	}
	
	@Override
	public void save(Room room) {
		getSession().save(room);		
	}

	@Override
	public List<Room> fetchAllRoom() {
		CriteriaQuery<Room> criteria=getSession().getCriteriaBuilder().createQuery(Room.class);
		criteria.select(criteria.from(Room.class));
		
		return getSession().createQuery(criteria).getResultList();
	}

	/*
	 * @Override public void update(Room room) { // TODO Auto-generated method stub
	 * 
	 * }
	 */

	@Override
	public Room fetchRoomById(int roomID) {
		/*
		 * CriteriaQuery<Room> criteria =
		 * getSession().getCriteriaBuilder().createQuery(Room.class);
		 * 
		 * criteria.select(criteria.from(Room.class))
		 * .where(getSession().getCriteriaBuilder()
		 * .equal(criteria.from(Room.class).get("roomID"), roomID));
		 * 
		 * Query<Room> query = getSession().createQuery(criteria); return
		 * query.uniqueResult();
		 */
		
		String sql = "SELECT * FROM rooms WHERE roomID = :roomID";
	    NativeQuery<Room> query = getSession().createNativeQuery(sql, Room.class);
	    query.setParameter("roomID", roomID);

	    return query.uniqueResult();
		
	}

		
		
}

