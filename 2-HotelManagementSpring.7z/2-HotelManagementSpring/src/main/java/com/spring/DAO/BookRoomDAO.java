package com.spring.DAO;

import java.util.List;

import com.spring.model.BookRoom;
import com.spring.model.Customer;

public interface BookRoomDAO {
	
	void save(BookRoom bookRoom);
	public List<BookRoom> fetchAllBookedRoom();

}
