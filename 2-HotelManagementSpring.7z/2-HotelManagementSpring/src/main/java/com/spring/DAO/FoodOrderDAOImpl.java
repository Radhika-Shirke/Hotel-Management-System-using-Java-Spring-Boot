package com.spring.DAO;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.model.FoodOrder;

@Repository
public class FoodOrderDAOImpl implements FoodOrderDAO {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	protected Session getSession()
	{
		return sessionFactory.getCurrentSession();
	}

	@Override
	@Transactional
	public void save(FoodOrder foodOrder) {
		getSession().save(foodOrder);
		
	}

}
