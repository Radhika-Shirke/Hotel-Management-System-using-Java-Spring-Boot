package com.spring.DAO;

import com.spring.model.FoodOrder;

public interface FoodOrderDAO {
	
	public void save(FoodOrder foodOrder);

}
