package com.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.spring.model.BookRoom;
import com.spring.model.Customer;
import com.spring.model.FoodOrder;
import com.spring.model.Room;
import com.spring.service.BookRoomService;
import com.spring.service.CustomerService;
import com.spring.service.FoodOrderService;
import com.spring.service.RoomService;

@Controller
public class HotelController {
	
	@Autowired
	RoomService roomService;
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	BookRoomService bookRoomService;
	
	@Autowired
	FoodOrderService foodOrderService;
 
	
	@RequestMapping("/load")
	public String goToBrowser(@ModelAttribute(name = "roominfo") Room room) {
	    
	    return "home";
	}
	
	
	
	/********************* ROOM BOOKING ***************************/
	
	@RequestMapping("/fetchRoom")
	public String getAllRooms(Model model)
	{
		
		model.addAttribute("RoomList",roomService.getAllRooms());
		return "roomwelcome";
	}
	
	@RequestMapping(value="/saveRoom")
	public ModelAndView saveRoom(@ModelAttribute(name = "bookRoomAttribute") BookRoom bookRoom)
	{
		bookRoomService.addRoom(bookRoom);
		return  new ModelAndView("saveRoom");
	}
	
	
	
	
	/********************* CUSTOMER REGISTRATION ***************************/
	
	@RequestMapping("/loadCustomer")
	public String goToBrowser(@ModelAttribute(name = "customerAttribute") Customer customer)
	{
		return "home";
	}
 
	
	@RequestMapping(value="/saveCustomer")
	//@ResponseBody
	public ModelAndView saveCustomer(@ModelAttribute(name = "customerAttribute") Customer customer)
	{
		customerService.addCustomer(customer);
		//return "Successfully added";
		return  new ModelAndView("saveCustomer");
	}
	@RequestMapping("/fetchCustomer")
	public String getAllCustomers(Model model)
	{
		
		model.addAttribute("customerList",customerService.findAllCustomer());
		return "welcome";
	}
	
	
	
	
	/********************* FOOD ORDER ***************************/
	
	@RequestMapping("/saveFoodOrder")
	public ModelAndView saveFoodOrder( @ModelAttribute(name="foodOrderAttribute") FoodOrder foodOrder)
	{
		foodOrderService.addFoodOrder(foodOrder);
		return new ModelAndView("saveFoodOrder");
	}
	
}

