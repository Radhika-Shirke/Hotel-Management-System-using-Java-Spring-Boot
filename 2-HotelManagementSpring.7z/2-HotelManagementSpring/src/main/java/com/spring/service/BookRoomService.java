package com.spring.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.spring.model.BookRoom;
import com.spring.model.Customer;

public interface BookRoomService {
 void addRoom(BookRoom bookRoom);
 public List<BookRoom> findAllBookRoom();

}
