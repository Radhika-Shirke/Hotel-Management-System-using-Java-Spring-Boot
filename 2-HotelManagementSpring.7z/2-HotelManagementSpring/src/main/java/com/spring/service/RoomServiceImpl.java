package com.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.DAO.CustomerDAO;
import com.spring.DAO.RoomDAO;
import com.spring.model.Customer;
import com.spring.model.Room;


@Service
public class RoomServiceImpl implements RoomService {
 
	@Autowired
	private RoomDAO roomDAO;
	
	@Autowired
	private CustomerDAO customerDAO;
 
	/*
	 * @Transactional public void addRoom(Room room) { roomDAO.save(room); }
	 */
	
	@Override
	@Transactional
	public List<Room> getAllRooms() {
        return roomDAO.fetchAllRoom();
    }
	
	@Override
	public Room findRoomById(int roomID)
	{
		return roomDAO.fetchRoomById(roomID);
	}

	/*
	 * @Override
	 * 
	 * @Transactional public void bookRoom(int roomID) { Room room =
	 * roomDAO.fetchRoomById(roomID); System.out.println(room); //Customer customer
	 * = customerDAO.fetchCustomerById(custId);
	 * 
	 * if(room != null && room.isAvailable()) { room.setAvailable(false);
	 * //room.setCustomer(customer); roomDAO.save(room);
	 * 
	 * }
	 * 
	 * }
	 */

 
}