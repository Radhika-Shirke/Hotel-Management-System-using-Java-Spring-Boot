package com.spring.service;

import java.util.List;

import com.spring.model.Room;

public interface RoomService {
//	public void addRoom(Room room);
	/* public void bookRoom(int roomID); */
	public Room findRoomById(int roomID);
	public List<Room> getAllRooms();
	
}