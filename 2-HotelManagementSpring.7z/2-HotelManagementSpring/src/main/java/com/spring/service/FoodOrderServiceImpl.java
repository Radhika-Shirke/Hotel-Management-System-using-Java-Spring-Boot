package com.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.DAO.FoodOrderDAO;
import com.spring.model.Customer;
import com.spring.model.FoodOrder;

@Service
public class FoodOrderServiceImpl implements FoodOrderService {

	@Autowired
	FoodOrderDAO foodOrderDAO;

	@Override
	public void addFoodOrder(FoodOrder foodOrder) {
		foodOrderDAO.save(foodOrder);
		
	}

}
