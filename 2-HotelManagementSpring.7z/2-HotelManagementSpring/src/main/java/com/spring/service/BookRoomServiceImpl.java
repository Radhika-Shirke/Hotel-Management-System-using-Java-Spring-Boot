package com.spring.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.DAO.BookRoomDAO;
import com.spring.model.BookRoom;
import com.spring.model.Customer;

@Service
public class BookRoomServiceImpl implements BookRoomService {
		
		@Autowired
		BookRoomDAO bookRoomDAO;

		@Transactional
		public void addRoom(BookRoom bookRoom) {
			bookRoomDAO.save(bookRoom);
		}

		@Override
		public List<BookRoom> findAllBookRoom() {
			return bookRoomDAO.fetchAllBookedRoom();
		}
		

}
