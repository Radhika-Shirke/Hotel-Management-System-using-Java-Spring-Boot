package com.spring.service;

import com.spring.model.FoodOrder;

public interface FoodOrderService {
	
	public void addFoodOrder(FoodOrder foodOrder);

}
